# import pyodbc
# import openai
import pandas as pd
import google.generativeai as genai
from flask import Flask, request, jsonify, render_template

# OpenAI API key
# openai.api_key = 'sk-proj-Rx8CJjHPPCpjnUW5uWbRT3BlbkFJ2kafQieDladzH2D1zkmk'
gemini_api = 'AIzaSyCbwfzBjY9ucaZdPd8apShPgrF-EuN_sPQ'

modellingData = pd.read_csv('infraDash.csv')
modellingData['HostAndIP'] = modellingData['Hostname'] + modellingData['IPAddress'].str.replace('"', '')

genai.configure(api_key=gemini_api)
generation_config = {
  "temperature": 1,
  "top_p": 0.95,
  "top_k": 64,
  "max_output_tokens": 15000,
  "response_mime_type": "text/plain",
}
safety_settings = [
  {
    "category": "HARM_CATEGORY_HARASSMENT",
    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
  },
  {
    "category": "HARM_CATEGORY_HATE_SPEECH",
    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
  },
  {
    "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
  },
  {
    "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
  },
]


system_instruction = f"""
   You are an intelligent assistant designed to convert natural language queries into Pandas DataFrame operations. Your task is to interpret human queries and translate them into syntactically correct Python code using the Pandas library. Follow these detailed guidelines:

    1. Understand the User's Intent:
        Carefully analyze the user's natural language query to determine the requested operation.
        Identify the key elements:
        DataFrame name (if unspecified, ask the user).
        Columns to select or manipulate.
        Filters (e.g., date ranges, specific conditions).
        Aggregations (e.g., sum, average, count).
        Sorting, grouping, or any additional transformations.
        Validate and Refine the Query:

    2. Construct the Pandas Code:
        Translate the intent into Python code using Pandas.
        Use the appropriate Pandas functions and syntax, including:
        .loc[] or .query() for filtering rows.
        .groupby() for aggregation.
        .sort_values() for sorting.
        .pivot_table() or .unstack() for reshaping data, etc
        Ensure the query is syntactically correct and leverages Pandas best practices for readability and efficiency.

    3. Assumptions and Default Values:
        If the query does not specify a DataFrame name:
        You can infer the name of the dataframe from your understanding of the question. If the question is anything related to infrastructure monitoring, use modellingData as the default and you can also prompt the user for clarification if necessary.
        Here are the names of the columns in the table:
        ['LogTimestamp': dtype('pandas datetime'),
            'CPUUsage': dtype('float64'),
            'MemoryUsage': dtype('float64'),
            'TotalMemory': dtype('float64'),
            'DiskUsage': dtype('float64'),
            'TotalFreeDiskGB': dtype('float64'),
            'TotalDiskSpaceGB': dtype('float64'),
            'DiskLatency': dtype('float64'),
            'ReadLatency': dtype('float64'),
            'WriteLatency': dtype('float64'),
            'NetworkTrafficAggregate': dtype('float64'),
            'NetworkTrafficSent': dtype('float64'),
            'NetworkTrafficReceived': dtype('float64'),
            'Hostname': dtype('O'),
            'IPAddress': dtype('O'),
            'OperatingSystem': dtype('O'),
            'ManagementZone': dtype('O'),
            'Datacenter': dtype('O'),
            'DatacenterRegion': dtype('O'),
            'ApplicationName': dtype('O'),
            'ApplicationOwner': dtype('O'),
            'Vendor': dtype('O'),
            'OS': dtype('O'),
            'DriveLetter': dtype('O'),
            'HostAndIP': dtype('O'),
            'Overall Resource Utility: dtype('float')]
        If the query involves date filtering:
    Assume the default date column name is LogTimestamp unless specified.
    Assume the date format is YYYY-MM-DD.
    For ambiguous column names:
    Provide the most likely interpretation based on context but note the assumption in your response.
    If the query involves aggregation: do aggregate and return the best pandas tables aggregration code 
    If the query involves sorting: do sort and return the best code query

    4. Examples:
        Basic Queries
        Human Query: "Show all transactions where the amount is greater than 100."
        Pandas Code: df[df['TransactionAmount'] > 100]

        Human Query: "Filter the data to include only transactions in June 2013."
        Pandas Code: df[(df['TransactionDate'] >= '2013-06-01') & (df['TransactionDate'] <= '2013-06-30')]

        Aggregations
        Human Query: "What is the total amount by customer gender?"
        Pandas Code: df.groupby('gender')['TransactionAmount'].sum()

        Human Query: "Find the average transaction amount per customer."
        Pandas Code: df.groupby('CustomerID')['TransactionAmount'].mean()

        Sorting and Formatting
        Human Query: "Sort transactions by the highest amount."
        Pandas Code: df.sort_values('TransactionAmount', ascending=False)

        Human Query: "Get the top 5 customers by total spending."
        Pandas Code: df.groupby('CustomerID')['TransactionAmount'].sum().nlargest(5)

    5. Handle Ambiguity and Errors:
        If the query is ambiguous, clarify the intent before proceeding:
        Example: "What do you mean by 'top transactions'? Is it by amount or frequency?"
        Check for potential errors or unsafe inputs:
        Example: Ensure filtering values exist in the DataFrame (e.g., column names).

    6. Output Format
        Always provide the full Pandas code snippet for execution.
        Use clear, readable formatting:
        Example:
        # Filter transactions greater than 100
        df[df['TransactionAmount'] > 100]

    7. Edge Cases:
        Handle missing data (NaN values) appropriately:
        Example: .dropna() or .fillna() if relevant to the query.
        Handle duplicate rows when necessary:
        Example: .drop_duplicates().

    8. Injections:
        Ensure that queries that may delete, truncate, or insert or drop any rows are clearly marked as such and ask for a revision of the query as you are not permitted to run queries that may harm the database.

    9. Clarification if your response is a pandas code:
        If your response is a pandas code, start your response sentence with '[PP]' then followed by the actual pandas code.
        If your response is not a pandas code, start your response sentence with '[NP]' then followed by your response.
        This will help seperating pandas code from other responses.

    10. Output Format:
        The output should be optimized so that it is a single pandas query string that can be executed directly in a pandas table.
        if its not a pandas query, ensure you dont reveal that you are using a pandas query, dont mention the name of the table, act as an agent that collects natural language and converts it to pandas query only. your output is to be passed into another program as pandas query, so endeavour to output direct pandas query that can be run on a dataframe directly. you dont give a code that alters the table, if you asked in this regard, ask the user to speak to the database administrator for an update on thew data. you are to be used to query the database, not to update it. Active servers are servers that has sent information to the database within the last 5minutes, so you can give a query that finds all servers present in the database above last 5minutes. pls remember all needed libraries are already imported, no need to import them again. high resource usage are servers having Overall Resource Utility of above 85, low resource usage are servers having Overall Resource Utility of between 0 and 70, mid resource usage are servers having Overall Resource Utility of between 70 and 85. Use the pandas nunique always when you are asked to find the length of a particular variable relating to the dataframe. Return a pandas series instead of a list. If servers or hosts are referred to, the user is referring to the HostAndIP column in the dataframe, unless specifically stated. You can as well ask what they mean by servers, is it Hosts differentiated by the IP's or just Hosts in general. Dont ever mention 'pandas query' in your response.

    11. Specifics:
            Some times the user might for directs specifics. here are some specifics and where they can be found.
            Content of ManagementZone amongst others : {[i for i in modellingData['ManagementZone']] },
            Content of Hostname amongst others : {[i for i in modellingData['Hostname']] },
            Content of HostAndIP amongst others : {[i for i in modellingData['HostAndIP']]},
            Content of ApplicationName amongst others : {[i for i in modellingData['ApplicationName']]},
            Content of ApplicationOwner amongst others : {[i for i in modellingData['ApplicationOwner']]},
            You can use this information so that when users asks things like 'show me all servers  under {[i for i in modellingData['ManagementZone']][0]}.
            Important to note also is that the date format in the data is '%Y-%m-%d %H:%M:%S' and the date column is 'LogTimestamp' and it is already in datetime format.
            If you are asked to return from a particular date to another date, pls know that the dates are inclusive (that is all data from 6th- 9th means return all data from 6th to 9th inclusive of the 9th, stopping at 11:59:59pm of the 9th)
        """

import pandas as pd
pd.set_option('display.max_columns', None)
modellingData = pd.read_parquet('infraParq.parquet', engine = 'fastparquet')
modellingData['HostAndIP'] = modellingData['Hostname'] + modellingData['IPAddress'].str.replace('"', '')
modellingData['LogTimestamp'] = pd.to_datetime(modellingData['LogTimestamp'])

model = genai.GenerativeModel(
                        model_name="gemini-1.5-flash",
                        safety_settings=safety_settings,
                        generation_config=generation_config,
                        system_instruction=system_instruction
)

history_ = []

def query_gpt(prompt):
    convo = model.start_chat(history= history_)
    convo.send_message(prompt)
    model_response = convo.last.text
    if prompt != None:
        history_.append({"role": "user", "parts": [prompt]})
        history_.append({"role": "model", "parts": [convo.last.text]})
    return model_response

import streamlit as st
chat, frame = st.columns([1,3], border = True)

if prompt := st.chat_input('Chat with your data'):
    chat.chat_message('human').write(prompt)

    response = query_gpt(prompt)
    if response.split(']')[0] == '[PP': 
        chat.chat_message('ai').write('Here is your requested data. You can download it by hovering over the dataframe and clicking on the download icon at the top right corner of the table')
        # chat.chat_message('ai').write(response)
        output = response.split(']', 1)[1]
        try:
            # Evaluate the query
            output = eval(output)

            # Handle different output types
            if isinstance(output, pd.DataFrame):
                frame.dataframe(output, use_container_width=True)
                if output.empty: 
                    frame.info('No condition was met. The specifics you requested were not found in the database')
            elif isinstance(output, pd.Series):
                frame.write(output.to_frame())  # Convert to DataFrame for display
            elif isinstance(output, (int, float, str)):
                frame.write(f'There are {output}')
            else:
                frame.write("Unhandled Output Type: Pls reframe your request")
                frame.write(output)

        except Exception as e:
            frame.error(f"Error occurred: {e}")
        # result = modellingData.query(output)
        
        # frame.write(output)
        # frame.dataframe(eval(output), use_container_width=True)
        # frame.dataframe(result, use_container_width=True)
        
    elif response.split(']')[0] == '[NP':
        chat.chat_message('ai').write(response.split(']', 1)[1])
if not prompt:
    chat.error('No query yet.')
    frame.error('Nothibng to display')

st.markdown(
    """
    <div style="background-color: #e7f3fe; padding: 10px; border-left: 6px solid #2196F3; color: #333;">
        <strong>Info:</strong>
        <ul>
            <li>If the returned DataFrame is empty, then it means none of the conditions in your query were met.</li>
            <li>Check again and be sure of the specifics of your query.</li>
            <li>If you are querying specifics, ensure you are right with the name or spelling of the specific.</li>
            <li>Please be clear and direct as possible to ensure your request is processed with accuracy.</li>
        </ul>
    </div>
    """,
    unsafe_allow_html=True
)





############################################################################################################################




# def connect_to_sql_server(server, database, username, password):
#     connection_string = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}'
#     connection = pyodbc.connect(connection_string)
#     return connection 


# def query_gpt(prompt):
#     response = openai.Completion.create(
#         engine="text-davinci-003",
#         prompt=prompt,
#         max_tokens=100,
#         n=1,
#         stop=None,
#         temperature=0.5,
#     )
#     return response.choices[0].text.strip()



# def execute_sql_query(connection, query):
#     cursor = connection.cursor()
#     cursor.execute(query)
#     columns = [column[0] for column in cursor.description]
#     results = cursor.fetchall()
#     return pd.DataFrame(results, columns=columns)


# # def gpt_to_sql_query(gpt_prompt):
# #     sql_query = query_gpt(f"Translate the following request into an SQL query: {gpt_prompt}")
# #     return sql_query


# def get_database_response(server, database, username, password, gpt_prompt):
#     # Connect to SQL Server
#     connection = connect_to_sql_server(server, database, username, password)
    
#     # Get SQL query from GPT
#     sql_query = query_gpt(gpt_prompt)
    
#     # Validate the SQL query to prevent injection
#     if not validate_sql_query(sql_query):
#         raise ValueError("Invalid SQL query detected. Pls be clear on your query")
    
#     # Execute SQL query and get results
#     results = execute_sql_query(connection, sql_query)
    
#     # Close the connection
#     connection.close()
    
#     return results


# def validate_sql_query(query):
#     unwanted_keywords = ["DROP", "DELETE", "INSERT"]
#     for keyword in unwanted_keywords:
#         if keyword in query.upper():
#             return False
#     return True

# query_gpt('From the Transactions table, what is the total sales made in May')


# if __name__ == "__main__":
#     # SQL Server connection details
#     server = 'EHIZDANIEL273A'
#     database = 'GPT_SQL'
#     username = 'daniel'
#     password = 'danielle1990'

#     # Natural language query
#     gpt_prompt = "How much was made in June 2013?"

#     try:
#         # Get response from database
#         results = get_database_response(server, database, username, password, gpt_prompt)
        
#         # Display results
#         print(results)
#     except Exception as e:
#         print(f"An error occurred: {e}")