import sqlite3
import pandas as pd 
import numpy as np
import json
import warnings 
from calculations import InfraCalculate as inf 
import datetime
from datetime import datetime, timedelta
import threading
import time
import schedule


def getConfig():
    with open('config.json') as config_file:
        configVar = json.load(config_file)
    return configVar
configVar = getConfig()
clientServer = configVar['client_server']
clientDB = configVar['client_db']
clientDBUserName = configVar['client_db_username']
clientDBPass = configVar['client_db_password']
client_table_name = configVar['client_table_name']

def liveDataHandler(db_path, table_name, start_date, stop_date, autoChanger):
    """
    Load data from the database and save it to a Parquet file.
    Args:
        db_path (str): Path to the SQLite database.
        table_name (str): Table name to query.
        start_date (str): Start date for filtering data.
        stop_date (str): Stop date for filtering data.
    Returns:
        pd.DataFrame: The loaded dataset.
    """
    autoChanger
    conn = sqlite3.connect(db_path)
    query = f"""
    SELECT * FROM '{table_name}' 
    WHERE LogTimestamp BETWEEN '{start_date}' AND '{stop_date}';
    """
    dataset = pd.read_sql_query(query, conn)
    dataset.to_parquet('workingData.parquet', engine='fastparquet', index=False)
    conn.close()
    dataset = pd.read_parquet('workingData.parquet', engine='fastparquet')
    return dataset

data = liveDataHandler('EdgeDB 2', 'Infra_Utilization', st.session_state['startDate'], st.session_state['stopDate'],  st.session_state['autoDataRefreshHelper'])
data['HostAndIP'] = data['Hostname'] + data['IPAddress'].str.replace('"', '')

if not data.empty:
    emptyData = False 
else:
    empytyDdata = True

