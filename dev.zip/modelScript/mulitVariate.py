import warnings 
warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
from prophet import Prophet
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.metrics import r2_score

# plt.style.use('ggplot')
# plt.style.use('fivethirtyeight')
sns.set(style = 'darkgrid')


class NathanClaire_MultiVariateTimeSeries:
    def __init__(self, target, data=None):
        """Initialize the NathanClaireMultiVariateTimeSeries class.
        Args:
            data (optional): The dataset to be used. If None, initializes with an empty DataFrame.
        """
        if data is not None:
            self.data = data
            self.target = target
        else:
            self.data = pd.DataFrame() 

        self.trainDatasets = {} # ------------ Keep splitted trainsets
        self.testDatasets = {} # ------------- Keep splitted testsets
        self.correlations = {} # ------------- Keep Correlation Coefficients
        self.trainedModels = {} # ------------ Keep trained models
        self.modelPredict = {} # ------------- Keep model output data
        self.selectModelPredict = {} # ------- Keep some selected model output data andits comparism with actual Y
        self.TSmodelScores = {} # -------------- Keep r2_scores of the univariate models
        self.futureForecast = {} # ----------- Keeps future forecast values for each feature


    def alreadyCleanedData(self, cleanedData):
        self.data = cleanedData


    def cleanData(self, dateFeature):
        self.data.set_index(pd.to_datetime(self.data[dateFeature]), inplace = True)
        self.data.drop([dateFeature],axis= 1, inplace = True)
        for i in self.data.columns:
            self.data[i] = self.data[i].str.replace(r'[^0-9.]', '', regex = True)
            self.data[i] = pd.to_numeric(self.data[i], errors = 'coerce')
        self.data.dropna(inplace = True)
        return self.data


    def visuals(self):
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots

        columns = [i for i in self.data.columns] # Define the columns to plot
        fig = make_subplots(rows=len(columns), cols=1, subplot_titles=columns) # Create a subplot figure with the number of columns specified
        # Add each column as a separate subplot
        for i, column in enumerate(columns):
            fig.add_trace(
                go.Scatter(x=self.data.index, y=self.data[column], mode='lines', name=column),
                row=i + 1, col=1
            )
        fig.update_layout(height=400 * len(columns), width=1300, title_text="Subplots of DataFrame Columns")
        fig.show()


    def correlationMatrix(self, showHeat = False):
        # Get the correlation coefficient of features against target feature and selecr only those with atleast 15% correlation
        for i in self.data.columns:
            if abs(self.data[self.target].corr(self.data[i]).round(2)) > 0.15:
                self.correlations[f'{i}'] = abs(self.data[self.target].corr(self.data[i]).round(2))       
        if showHeat == True:
            plt.figure(figsize=(12, 0.5 * self.data.shape[1]))
            return sns.heatmap(self.data.corr(), annot = True, cmap = 'BuPu')
        else:
            return self.data.corr()


    def generateModelData(self, split_date, show_split = False):
        self.split_date = split_date
        self.trainSplit = self.data.loc[self.data.index <= self.split_date].copy()
        self.testSplit = self.data.loc[self.data.index > self.split_date].copy()

        for i in self.data.columns:
            train = pd.DataFrame()
            train['y'] = self.trainSplit[i]
            train['ds'] = self.trainSplit.index
            self.trainDatasets[f'{i}'] = train # Append the traindata to the list of trainDatasets

            test = pd.DataFrame()
            test['y'] = self.testSplit[i]
            test['ds'] = self.testSplit.index
            self.testDatasets[f'{i}'] = test

        if show_split == True:
            num_plots = len(self.trainDatasets)
            plt.figure(figsize=(15, 5*len(self.trainDatasets)))

            # Loop through the items in train and test
            for i, (train_key, test_key) in enumerate(zip(self.trainDatasets.keys(), self.testDatasets.keys())):
                plt.subplot(num_plots, 1, i + 1)
                plt.plot(self.trainDatasets[train_key]['ds'], self.trainDatasets[train_key][self.trainDatasets[train_key].columns[0]], color = 'blue')
                plt.plot(self.testDatasets[test_key]['ds'], self.testDatasets[test_key][self.testDatasets[test_key].columns[0]], color = 'orange')

                # Highlight the split point
                plt.axvline(x=pd.to_datetime(split_date), color='red', linestyle='--', label='Split Date')

    
    def modelling(self, timeDiff, NumOfDays, plotPerformance = False, similarityScore = False, homoscedasticity = False, returnFullData = False):
        # create models for each feature only if they have a target correlation of atleast 15%
        print(f'Creating Univariate Models for each features ..... \n')
        for name, (train, test) in enumerate(zip(self.trainDatasets.keys(), self.testDatasets.keys())):
            if train in [i for i in self.correlations.keys()]: # Check if the column is in the >15% correlation list of columns before modelling it
                model = Prophet()    
                model.fit(self.trainDatasets[train])
                modelPredict = model.predict(self.testDatasets[test])
                self.trainedModels[f'{train}_model'] = model
                self.modelPredict[f'{test}modelPredict'] = modelPredict
                                                                    
                df = modelPredict[['ds', 'yhat', 'yhat_lower', 'yhat_upper']]
                df = pd.merge(df, self.testDatasets[test]['y'], on = df['ds'], how = 'inner')
                df.set_index(df['ds'], inplace = True )
                df.drop(['key_0', 'ds'], axis = 1, inplace = True)
                self.selectModelPredict[f'{train}_predictOutput'] = df
                self.TSmodelScores[f'{train}'] = r2_score(self.selectModelPredict[f'{train}_predictOutput']['yhat'], self.testDatasets[test]['y'])

        self.futureForecastFrame = pd.DataFrame() # Create an empty frame to keep dataframe of forecasted frame

        if self.TSmodelScores[self.target] < 0.90:
            print(f'\nUnivariate Modelling Score of Target is too low ... Reverting to Advanced Multiple Linear Modelling\n')

            # start by Concatenating the processed train and test data to get a full data, then create future dates
            # Also consider only columns that previously had univariate models created for them
            for key, value in enumerate(self.TSmodelScores.keys()): # COnsider only columns that  
                forecastData = pd.concat([self.trainDatasets[value], self.testDatasets[value]], axis= 0) # Use this coz it has the ds and y
                forecastModel = Prophet() # Create new model that trains on the entire data, then predicts the future data
                forecastModel.fit(forecastData)

                # Create Future data with period of NumOfDays, 24hrs by NumOfDays, 1440mins by NumOF Days. This adds the row to the entire dataset
                if 'minute' in timeDiff:
                    timeDif = int(timeDiff.replace('minute', ''))
                    numOfMinutesInDay = 1440 / timeDif # 1440 minutes in a day
                    period = int(NumOfDays * numOfMinutesInDay)
                    future = forecastModel.make_future_dataframe(periods = period, freq = 'min')  
                elif 'hour' in timeDiff:
                    timeDif = int(timeDiff.replace('hour', ''))
                    numOfHoursInDay = 24 / timeDif  # 24 hours in a day
                    period = int(NumOfDays * numOfHoursInDay)
                    future = forecastModel.make_future_dataframe(periods=period, freq='H')
                elif 'day' in timeDiff:
                    period = NumOfDays # Set directly to days since it represents the number of days
                    future = forecastModel.make_future_dataframe(periods=period, freq='D')
                elif 'month' in timeDiff:
                    period = NumOfDays  # Set directly to months since it represents the number of months
                    future = forecastModel.make_future_dataframe(periods=period, freq='month')
                elif 'year' in timeDiff:
                    period = NumOfDays  # Set directly to years since it represents the number of years
                    future = forecastModel.make_future_dataframe(periods=period, freq='Y')
                else:
                    raise ValueError("Invalid time measure. Use like '1minute' or '30minutes' or '1hour' or '30hours' or day or month or year")
                
                forecastModelPred = forecastModel.predict(future) # Predict the future with the new model
                futureOnly = forecastModelPred.copy().loc[forecastModelPred['ds'] > str(self.data.index.max())][['ds', 'yhat']] # collect predicted future values
                forecastedValues = forecastModelPred.copy()
                forecastedValues['yhat'] = forecastModelPred['yhat'].apply(lambda x: round(x, 2))
                self.futureForecast[value] = forecastedValues['yhat']  # A dictionary that saves the future forecasts
                self.futureForecastFrame.index = forecastedValues['ds']
                self.futureForecastFrame[value] = forecastedValues['yhat'].values # A dataframe that keeps the future forecasts

        self.futureForecastFrame['hour_of_day'] = self.futureForecastFrame.index.hour
        self.futureForecastFrame['month'] = self.futureForecastFrame.index.month
        self.futureForecastFrame['dayofyear'] = self.futureForecastFrame.index.dayofyear
        self.futureForecastFrame['dayofmonth'] = self.futureForecastFrame.index.day

        # Extract day of the week (0=Monday, 6=Sunday)
        self.futureForecastFrame['day_of_week'] = self.futureForecastFrame.index.day_name()  # Returns the name of the day
        day_mapping = {
            'Monday': 0,
            'Tuesday': 1,
            'Wednesday': 2,
            'Thursday': 3,
            'Friday': 4,
            'Saturday': 5,
            'Sunday': 6 }
        # Add the 'day_of_week' column
        self.futureForecastFrame['day_of_week'] = self.futureForecastFrame.index.day_name().map(day_mapping)
        # Extract week of the month
        WeekMonth = []
        for u in self.futureForecastFrame.index.day:
            if u <= 7:
                WeekMonth.append(1)
            elif u > 7 and u <= 14:
                WeekMonth.append(2)
            elif u > 14 and u <= 21 :
                WeekMonth.append(3)
            elif u > 21 and u <= 31:
                WeekMonth.append(4)

        self.futureForecastFrame['week_of_month'] = pd.Series(WeekMonth, index = self.futureForecastFrame.index)
        self.futureForecastFrame.dropna(inplace = True)

        from sklearn.ensemble import RandomForestRegressor
        from sklearn.model_selection import train_test_split
        x = self.futureForecastFrame.drop(self.target, axis = 1)
        y = self.futureForecastFrame[self.target]
        xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size = 0.15, shuffle = False)
        model = RandomForestRegressor()
        model.fit(xtrain, ytrain)
        pred = model.predict(xtest)
        self.regModelScore = r2_score(pred, ytest)

        if self.regModelScore < self.TSmodelScores[self.target]:
            print(f'\nMultiLinear Regression Model Score {self.regModelScore.round(2)} is lower than Univariate TimeSeries Score {self.TSmodelScores[self.target].round(2)}.\nReverting back to Univariate TimeSeries Model')
        else:
            print(f'\nMultiLinear Regression Model Score {self.regModelScore.round(2)} performed better than Univariate TimeSeries Score {self.TSmodelScores[self.target].round(2)}')

        if plotPerformance == True:
            # Plot the forecast with the actuals
            future = self.futureForecastFrame.loc[self.futureForecastFrame.index > str(self.data.index.max())]
            for i in self.futureForecastFrame.columns:
                if i in self.TSmodelScores.keys():
                    f, ax = plt.subplots(figsize=(15, 4))
                    ax.plot(self.data.index, self.data[i], color='r', label='Training Data') # Plot training data
                    ax.plot(future.index, future[i], label='Predicted', color='blue')  # Plot the forecast for the first week
                    ax.set_title(f'{NumOfDays} Days Future Forecast') 
                    # Highlight the split point
                    plt.axvline(x=pd.to_datetime(self.split_date), color='black', linestyle='--', label='Test Split')
                    plt.axvline(x=pd.to_datetime(str(self.data.index.max())), color='green', linestyle='--', label='Future Split')
                    ax.legend()
                    plt.show()


        # if homoscedasticity == True:
        #     for name, (train, test) in enumerate(zip(self.trainDatasets.keys(), self.testDatasets.keys())):
        #         plt.figure(figsize=(10,3))
        #         sns.regplot(x = self.selectModelPredict[f'{train}_predictOutput']['yhat'], y = self.testDatasets[test]['y'], ci = 0)
        #         plt.xlabel(f'Predicted {train}')
        #         plt.ylabel(f'Actual {train}')
        #         plt.title(f"Correlation Btw Actual and Predicted  {train} is: {self.selectModelPredict[f'{train}_predictOutput']['yhat'].corr(self.testDatasets[test]['y']).round(2)}")
        #         plt.show()

        #     def display_full_dataframe(df):
        #         with pd.option_context('display.max_rows', None):
        #             display(df)
        #     for name, (train, test) in enumerate(zip(self.trainDatasets.keys(), self.testDatasets.keys())):
        #         display(display_full_dataframe(self.selectModelPredict[f'{train}_predictOutput']))



