import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
from uniVariate import NathanClaire_UnivariateTimeSeries as uni
import warnings
warnings.filterwarnings('ignore')
st.set_option('deprecation.showPyplotGlobalUse', False)

# Add header and Subheader 
st.markdown("<h1 style = 'color: #124076; text-align: center; font-size: 60px; font-family: Helvetica'>Edge Future Forecast</h1>", unsafe_allow_html = True)
st.markdown("<h4 style = 'margin: -30px; color: #F11A7B; text-align: center; font-family: cursive '>Time Based Prediction</h4>", unsafe_allow_html = True)
st.markdown("<br>", unsafe_allow_html= True)

# Add an Image 
st.sidebar.image('pngwing.com (12).png' , caption = 'Input your data')
uploaded_file = st.sidebar.file_uploader("Choose a CSV file", type="csv")

if uploaded_file is not None:
    # Read the CSV file into a DataFrame
    data = pd.read_csv(uploaded_file)
    dateFeature = st.text_input('What column is your date feature: Pls reminded that it is case sensitive')
    if dateFeature:
        data.set_index(data[dateFeature], inplace = True)
        data.index = pd.to_datetime(data.index)
        data.drop(dateFeature, axis = 1, inplace = True)

        st.dataframe(data, use_container_width=True)

        ts = uni(data = data[[f'{data.columns[-1]}']], feature = f'{data.columns[-1]}')
        st.plotly_chart(ts.visual())

        st.markdown("<br>", unsafe_allow_html= True)
        split_date = st.text_input(label = 'choose your preferred date to split into train and test dataset. Format: 2024-01-01 00:00:00')
        show_split = st.selectbox('Do you want to show the splitted data ? ', ('True', 'False'))
        if split_date:
            if show_split:
                split_date = split_date
                st.pyplot(ts.generateModelData(split_date=split_date, show_split=True))
            else:
                ts.generateModelData(split_date=split_date, show_split=False)
        else:
            split_date = data.iloc[-70: ].index.min()
            st.pyplot(ts.generateModelData(split_date=split_date, show_split=True))

        proceed = st.button('Proceed to modelling and model testing: ')
        homo  = st.button('Click to view homoscedsticity of the model: ')
        if proceed:
                st.success(f'Modelling your data\n')
                st.pyplot(ts.modelling(plotPerformance = True, similarityScore = True, homoscedasticity = False, returnFullData = False))
        if homo:
            st.success(f'Displaying homescedasticity of your model\n')
            st.pyplot(ts.modelling(plotPerformance = True, similarityScore = True, homoscedasticity = False, returnFullData = False))

            st.pyplot(ts.modelling(plotPerformance = False, similarityScore = True, homoscedasticity = True, returnFullData = False))        
            

        st.markdown("<br>", unsafe_allow_html= True)
        st.markdown("<br>", unsafe_allow_html= True)
        st.markdown("<h4 style = 'margin: -30px; color: #F11A7B; text-align: center; font-family: cursive '>Future Forecasting</h4>", unsafe_allow_html = True)

        times = st.text_input('select the time difference in your data. Format: 10minute, 30minute, 1hr, 2hr, 1day, 1month...')
        days = st.text_input('select your preffered number of days to predict into the future')
        if times:
            if days:
                days = int(days)
                st.pyplot(ts.futureForecast(timeDiff = times, NumOfDays = days, getForecast = False, plotForecast = True,  measure = False))
                st.markdown("<br>", unsafe_allow_html= True)
                st.success('Pls download your forecasted data')
                forecast = ts.futureForecast(timeDiff = times, NumOfDays = days, getForecast = True, plotForecast = False,  measure = False)

                saving = forecast.to_csv(index=False).encode('utf-8')
                st.download_button(
                "Click to download your forecasted values",
                saving,
                "forecastedValues.csv",
                "text/csv",
                key='download-csv')
            else:
                st.error('You have to choose range of days for forecast')
        else:
            st.error('You have to choose a time interval')

