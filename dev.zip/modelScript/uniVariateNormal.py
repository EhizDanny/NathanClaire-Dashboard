import warnings 
warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go

from prophet import Prophet
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.metrics import r2_score


plt.style.use('ggplot')
# plt.style.use('fivethirtyeight')
sns.set(style = 'darkgrid')

def mean_absolute_percentage_error(y_true, y_pred): 
    """Calculates MAPE given y_true and y_pred"""
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100


class NathanClaire_UnivariateTimeSeries:
    def __init__(self, data, feature, timeFeature, serverName, resamplePeriod):
        self.data = data
        self.feature = feature 
        self.serverName = serverName
        self.timeFeature = timeFeature
        self.resamplePeriod = resamplePeriod

        self.trainSplit = None, 
        self.testSplit = None
        self.trainData = None, 
        self.testData = None
        self.split_date = None

        self.data = self.data[self.data.HostAndIP == self.serverName]
        self.timeFeature = pd.to_datetime(self.data[self.timeFeature])
        self.data.set_index(self.timeFeature, inplace = True)
        self.data = self.data.resample(str(self.resamplePeriod) +'min').agg({
                        'TotalMemory': 'last',  
                        'TotalFreeDiskGB': 'last',      # Latest freedisk value
                        'CPUUsage': 'mean',           # Example: Average CPU usage
                        'MemoryUsage': 'mean',        # Example: Average memory usage
                        'DiskUsage': 'mean',          # Example: Average disk usage
                        'NetworkTrafficSent': 'sum',  # Total traffic sent
                        'NetworkTrafficReceived': 'sum', # Total traffic received
                        })
        
        
    def cleanData(self, signInplace, toNumeric = True):
        if toNumeric == True:
            self.data[self.feature] = self.data[self.feature].str.replace(r'[^0-9.]', signInplace, regex = True)
            self.data[self.feature] = pd.to_numeric(self.data[self.feature], errors = 'coerce')
            self.data.dropna(inplace = True)
            self.data.set_index(pd.to_datetime(self.data['Date']), inplace = True)
            self.data.drop(['Date'],axis= 1, inplace = True)
            return self.data
        elif toNumeric == False:
            self.data[self.feature] = self.data[self.feature].str.replace(r'[^0-9.]', signInplace, regex = True)
            self.data.dropna(inplace = True)
            self.data.set_index(pd.to_datetime(self.data['Date']), inplace = True)
            self.data.drop(['Date'],axis= 1, inplace = True)
            return self.data
        else:
            print('Wrong innput')


    def visual(self):
        fig = px.line(x = self.data.index, y = self.data[self.feature], width = 1000)
        fig.update_layout(template='plotly_white',
            showlegend=False,
            title={'text': f'TimeSeries Movement Of {self.feature}', 'x': 0.3},
            # yaxis=dict(range=[-10, 100]),  # Adjust Y-axis limits based on your thresholds
            xaxis_title = None, yaxis_title = None, height = 320, margin=dict(l=0,  r=0, t=40, b=10  ))
        # st.plotly_chart(fig, use_container_width=True)  
        return fig
    
    def generateModelData(self, split_date, show_split = False):
        self.split_date = split_date
        self.trainSplit = self.data.loc[self.data.index <= self.split_date].copy()
        self.testSplit = self.data.loc[self.data.index > self.split_date].copy()

        self.trainData = pd.DataFrame()
        self.trainData['y'] = self.trainSplit[self.feature]
        self.trainData['ds'] = self.trainSplit.index

        self.testData = pd.DataFrame()
        self.testData['y'] = self.testSplit[self.feature]
        self.testData['ds'] = self.testSplit.index

        if show_split == True:
            # Plot train and test so you can see where we have split
            plt.figure(figsize=(15, 6))
            # sns.set(style = 'darkgrid')
            plt.plot(self.trainSplit.index, self.trainSplit[self.feature], label='Train Data', color='blue')
            plt.plot(self.testSplit.index, self.testSplit[self.feature], label='Test Data', color='green')

            # Highlight the split point
            plt.axvline(x=pd.to_datetime(self.split_date), color='red', linestyle='--', label='Split Date')

            plt.title('Train and Test Data Split')
            plt.xlabel('Date')
            plt.ylabel(self.feature)
            plt.legend()
            plt.show()

    
    def modelling(self, plotPerformance = False, similarityScore = False, homoscedasticity = False, returnFullData = False):
        model = Prophet()
        model.fit(self.trainData)
        modelPredict = model.predict(self.testData)

        df = modelPredict[['ds', 'yhat', 'yhat_lower', 'yhat_upper']]
        df = pd.merge(df, self.testData['y'], on = df['ds'], how = 'inner')
        df.set_index(df['ds'], inplace = True )
        df.drop(['key_0', 'ds'], axis = 1, inplace = True)

        if plotPerformance == True:
            # sns.set(style = 'darkgrid')
            f, ax = plt.subplots(figsize = (17,7))
            ax.plot(self.testData.index, self.testData['y'], color = 'r')
            fig = model.plot(modelPredict, ax = ax)
            plt.axvline(x=pd.to_datetime(self.split_date), color='red', linestyle='--', label='Split Date')
            plt.legend()
            plt.show()
        
        if similarityScore == True:
            print(f"Coef Of Determination: {r2_score(df['yhat'], self.testData['y'])}\nCorrelation Coefficient: {df['yhat'].corr(self.testData['y'])}\n")

        if homoscedasticity == True:
            plt.figure(figsize=(10,3))
            sns.regplot(x = df['yhat'], y = self.testData['y'], ci = 0)
            plt.xlabel('Predicted Value')
            plt.ylabel('Actual Value')
            plt.title(f"Correlation Btw Actual and Predicted is: {int((df['yhat'].corr(self.testData['y']).round(2)) * 100)}%")
            plt.show()

        # if returnFullData == True:
        #     def display_full_dataframe(df):
        #         with pd.option_context('display.max_rows', None):
        #             display(df)
        #     return display_full_dataframe(df)

        # return modelPredict

    def futureForecast(self, timeDiff: int, interval:str, NumOfDays: int, getForecast = False, plotForecast = False,  measure = False):
        # started by Concatenating the processed train and test data to get a full data, then create future dates
        forecastData = pd.concat([self.trainData, self.testData], axis= 0) 

        forecastModel = Prophet() # Create new model that trains on the entire data, then predicts the future data
        forecastModel.fit(forecastData)

        # Create Future data with period of NumOfDays, 24hrs by NumOfDays. This adds the 1hr row for NumOfDays to the entire dataset
        # if 'minutes' in timeDiff:
        # if any(time in timeDiff for time in ['min', 'minutes', 'minute']):
        #     timeDiff = int(timeDiff.replace('minutes', '').replace('minute', '').replace('min', '').strip())
        if interval == 'Minute':
            numOfMinutesInDay = 1440 / timeDiff # 1440 minutes in a day
            period = int(NumOfDays * numOfMinutesInDay)
            future = forecastModel.make_future_dataframe(periods = period, freq = f'{timeDiff}min')  
        # elif 'hour' in timeDiff:
        elif interval == 'Hour':
            # timeDiff = int(timeDiff.replace('hour', ''))
            numOfHoursInDay = 24 / timeDiff  # 24 hours in a day
            period = int(NumOfDays * numOfHoursInDay)
            future = forecastModel.make_future_dataframe(periods=period, freq=f'{timeDiff}H')
        # elif 'day' in timeDiff:
        elif interval == 'Day':
            period = NumOfDays # Set directly to days since it represents the number of days
            future = forecastModel.make_future_dataframe(periods=period, freq='D')
        # elif 'month' in timeDiff:
        elif interval == 'Month':
            period = NumOfDays  # Set directly to months since it represents the number of months
            future = forecastModel.make_future_dataframe(periods=period, freq='Y')
        # elif 'year' in timeDiff:
        elif interval == 'Year':
            period = NumOfDays  # Set directly to years since it represents the number of years
            future = forecastModel.make_future_dataframe(periods=period, freq='Y')
        else:
            raise ValueError("Invalid time measure. Use like '1minute' or '30minutes' or '1hour' or '30hours' or day or month or year")
        
        forecastModelPred = forecastModel.predict(future) # Predict the future with the new model
        # collect forecasted values 
        forecastedValues = forecastModelPred.loc[forecastModelPred['ds'] > str(self.data.index.max())][['ds', 'yhat', 'yhat_upper', 'yhat_lower']]
        forecastedValues['yhat'] = forecastedValues['yhat'].apply(lambda x: round(x, 2))

        if plotForecast == True:
            # Plot the forecast with the actuals
            f, ax = plt.subplots(figsize=(15, 5))

            ax.scatter(self.data.index, self.data[self.feature], color='r', label='Training Data') # Plot training data
            ax.plot(forecastModelPred['ds'], forecastModelPred['yhat'], label='Predicted', color='blue')  # Plot the forecast for the first week
            ax.fill_between(forecastModelPred['ds'], forecastModelPred['yhat_lower'], forecastModelPred['yhat_upper'], color='yellow', alpha=0.4) #plot the uncertainty intervals
            ax.set_title(f'{NumOfDays} Days Future Forecast') 

            # Highlight the split point
            plt.axvline(x=pd.to_datetime(self.split_date), color='black', linestyle='--', label='Test Split')
            plt.axvline(x=pd.to_datetime(str(self.data.index.max())), color='green', linestyle='--', label='Future Split')
            ax.legend()
            # fig = go.Figure()

            # # Add the training data as scatter points
            # fig.add_trace(go.Scatter(
            #     x=self.data.index,
            #     y=self.data[self.feature],
            #     mode='markers',
            #     name='Training Data',
            #     marker=dict(color='red')
            # ))
            # # Add the forecast line
            # fig.add_trace(go.Scatter(
            #     x=forecastModelPred['ds'],
            #     y=forecastModelPred['yhat'],
            #     mode='lines',
            #     name='Predicted',
            #     line=dict(color='blue')
            # ))
            # # Add the uncertainty intervals as filled area
            # fig.add_trace(go.Scatter(
            #     x=pd.concat([forecastModelPred['ds'], forecastModelPred['ds'][::-1]]),  # Concatenate for upper and lower bounds
            #     y=pd.concat([forecastModelPred['yhat_upper'], forecastModelPred['yhat_lower'][::-1]]),  # Upper bound first, then lower bound reversed
            #     fill='toself',
            #     fillcolor='rgba(255, 255, 0, 0.4)',  # Yellow with transparency
            #     line=dict(color='rgba(255, 255, 0, 0)'),
            #     name='Uncertainty Interval',
            #     hoverinfo="skip"
            # ))
            # # Add vertical line for the test split
            # fig.add_vline(
            #     x=pd.to_datetime(self.split_date),
            #     line=dict(color="black", dash="dash"),
            #     annotation_text="Test Split",
            #     annotation_position="top right"
            # )
            # # Add vertical line for the future split
            # fig.add_vline(
            #     x=pd.to_datetime(str(self.data.index.max())),
            #     line=dict(color="green", dash="dash"),
            #     annotation_text="Future Split",
            #     annotation_position="top left"
            # )
            # # Update layout
            # fig.update_layout(
            #     title=f'{NumOfDays} Days Future Forecast',
            #     xaxis_title='Date',
            #     yaxis_title=self.feature,
            #     legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1),
            #     template='plotly_white'
            # )
            
        if measure == True:
            forecastedValues['yhat'] = forecastedValues['yhat'].apply(lambda x: str(x) + f'{measure}')

        if getForecast == True:
            return forecastedValues
        elif plotForecast == True:
            return f
        
        # if measure == True:
        #     forecastedValues['yhat'] = forecastedValues['yhat'].apply(lambda x: str(x) + f'{measure}')

        # if getForecast == True:
        #     return forecastedValues