"""
import threading
import time 


done=False 
def worker():
    cou = 0
    while not done:
        time.sleep(1)
        cou += 1
        print(cou)

worker()

stop = input('Press enter to quit')
if stop:
    done = True
    """

# The loop will not be stop able because the worker function hasnt stopped running. Hence the need of threading 
# The threading module allows us to run multiple threads in a program.

import threading
import time 


done=False 
def worker():
    cou = 0
    while not done:
        time.sleep(1)
        cou += 1
        print(cou)

threading.Thread(target = worker).start()
# We can as well pass arguments to the function as in :
# threading.Thread(target = worker, daemon = True, args = ("ABC",))
# The comma behind is very important to add

input('Press enter to quit')
done = True