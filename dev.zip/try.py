# import streamlit as st 

# if 'name' not in st.session_state:
#     st.session_state.name = 'Mike'
# st.write(f'Hello there {st.session_state.name}')
# newName = st.text_input('Enter your name')
# def changeName(new):
#     st.session_state['name'] = new
# st.button('Click', on_click=changeName, args = [newName])

# # OR 

# if 'name' not in st.session_state:
#     st.session_state.name = 'Mike'
# def changeName():
#     if st.session_state.change_it:
#         st.session_state.name = st.session_state.change_it
# st.write(f'Hello there {st.session_state.name}')
# newName = st.selectbox('Change name', ['Eva', 'Riley', 'Freshy'], on_change=changeName, key = 'change_it')

import streamlit as st


from streamlit_extras.stylable_container import stylable_container
@st.fragment
def fg():
    with stylable_container(
                    key="container_with_border",
                    css_styles="""{
                            border: 1px solid rgba(49, 51, 63, 0.2);
                            box-shadow: rgba(14, 30, 37, 0.12) 0px 2px 4px 0px, rgba(14, 30, 37, 0.32) 0px 2px 16px 0px;
                            border-radius: 0.3rem;
                            padding-bottom: 5px;
                            margin-top: -10px
                        }""",):

        if 'stop' not in st.session_state:
            st.session_state['stop'] = '2024-01-02'
        if  'start' not in st.session_state:
            st.session_state['start'] = '2024-01-01'
        st.write('Hello there')
        st.write(f'This is thew start and stop date {st.session_state.start} - {st.session_state.stop}')

        def cha():
            if st.session_state.datech:
                st.session_state.start, st.session_state.stop = st.session_state.datech
                
        con = st.date_input('Input date', value = (st.session_state.start, st.session_state.stop), key = 'datech', on_change=cha)
fg()
# class LiveDataHandler:
#     def __init__(self, db_path, table_name, refresh_interval=1):
#         """
#         Initialize the LiveDataHandler with database and refresh settings.
#         Args:
#             db_path (str): Path to the SQLite database.
#             table_name (str): Table name in the database.
#             refresh_interval (int): Interval in minutes for refreshing data.
#             start_days_ago (int): Number of days back to set the default start date.
#         """
#         self.db_path = db_path
#         self.table_name = table_name
#         self.refresh_interval = timedelta(minutes=refresh_interval)
#         self.last_modified = None

#         # Initialize session state variables
#         if 'last_update_time' not in st.session_state:  # Keep track of last update time
#             st.session_state['last_update_time'] = datetime.now()

#     def should_reload_data(self):
#         """Check if data needs to be reloaded based on the refresh interval."""
#         return datetime.now() - st.session_state['last_update_time'] > self.refresh_interval

#     @staticmethod  # Makes the function independent of the class
#     @st.cache_data
#     def load_data_from_db(db_path, table_name, start_date, stop_date, autoChanger):
#         """
#         Load data from the database and save it to a Parquet file.
#         Args:
#             db_path (str): Path to the SQLite database.
#             table_name (str): Table name to query.
#             start_date (str): Start date for filtering data.
#             stop_date (str): Stop date for filtering data.
#         Returns:
#             pd.DataFrame: The loaded dataset.
#         """
#         autoChanger
#         conn = sqlite3.connect(db_path)
#         query = f"""
#         SELECT * FROM '{table_name}' 
#         WHERE LogTimestamp BETWEEN '{start_date}' AND '{stop_date}';
#         """
#         dataset = pd.read_sql_query(query, conn)
#         dataset.to_parquet('workingData.parquet', engine='fastparquet', index=False)
#         conn.close()
#         dataset = pd.read_parquet('workingData.parquet', engine='fastparquet')
#         return dataset

#     @st.cache_data
#     def load_data_from_db(db_path, table_name, start_date, stop_date, autoChanger):
#         """
#         Load data from the database and save it to a Parquet file.
#         Args:
#             db_path (str): Path to the SQLite database.
#             table_name (str): Table name to query.
#             start_date (str): Start date for filtering data.
#             stop_date (str): Stop date for filtering data.
#         Returns:
#             pd.DataFrame: The loaded dataset.
#         """
#         autoChanger
#         conn = sqlite3.connect(db_path)
#         query = f"""
#         SELECT * FROM '{table_name}' 
#         WHERE LogTimestamp BETWEEN '{start_date}' AND '{stop_date}';
#         """
#         dataset = pd.read_sql_query(query, conn)
#         dataset.to_parquet('workingData.parquet', engine='fastparquet', index=False)
#         conn.close()
#         dataset = pd.read_parquet('workingData.parquet', engine='fastparquet')
#         return dataset
    
#     @staticmethod
#     @st.cache_data
#     def load_data_from_parquet(parquet_file, last_mod_time):
#         last_mod_time
#         return pd.read_parquet(parquet_file, engine='fastparquet')

#     def get_data(self):
#         if self.should_reload_data():
#             st.session_state['last_update_time'] = datetime.now()

#             return self.load_data_from_db(
#                 self.db_path,
#                 self.table_name,
#                 st.session_state['startDate'],
#                 st.session_state['stopDate'],
#                 st.session_state['autoDataRefreshHelper']
#             )
        





# if any([st.session_state.ao, st.session_state.an, st.session_state.vend, st.session_state.dc, st.session_state.mz, st.session_state.oss]):
#        st.session_state['data'] = st.session_state['data'][
#            (st.session_state['data']['ApplicationOwner'] == st.session_state.ao if st.session_state.ao != 'Select All' else True) &
#            (st.session_state['data']['ApplicationName'] == st.session_state.an if st.session_state.an != 'Select All' else True) &
#            (st.session_state['data']['Vendor'] == st.session_state.vend if st.session_state.vend != 'Select All' else True) &
#            (st.session_state['data']['Datacenter'] == st.session_state.dc if st.session_state.dc != 'Select All' else True) &
#            (st.session_state['data']['ManagementZone'] == st.session_state.mz if st.session_state.mz != 'Select All' else True) &
#            (st.session_state['data']['OS'] == st.session_state.oss if st.session_state.oss != 'Select All' else True)
#        ]